# EtudeFrInclusif

This project provides methods to detect inclusive french within document in french. It also provides a toolkit aimed to build a inclusive french corpus
